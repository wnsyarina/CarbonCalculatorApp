package com.example.module2;

import androidx.lifecycle.ViewModel;

public class FoodDietCalculatorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}