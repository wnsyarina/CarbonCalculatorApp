package com.example.module2;

import androidx.lifecycle.ViewModel;

public class TrannsportationCalViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}